package com.model;

public class Student {
	/*
	 * Static: One time initialization for example database connection initialization
	 * 1. Without object we can call static variable or function
	 * 2. Static can be accessed by the class name
	 * 3. Static will exists/execute before the constructor
	 * 4. Property of class, not the property of Object
	 * 5. class variable or method
	 */

	/**
	 * Static variable
	 */
	private static int counter=0;

	public static int getCounter() {
		return counter;
	}
/*
	public static void setCounter(int counter) {
		Student.counter = counter;
	}*/
	/**
	 * Constructor
	 */
	public Student() {
		counter++;
		System.out.println(" Default contructor Executed...");
	}
	
	/**
	 * Non static variable and methods
	 */
	private String name;
	
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}

}
