

import static com.model.Student.*;

import com.model.Student; 

public class StaticMain {

	public static void main(String[] args) {
		
		// Set the value to the static variable
		//Student.counter =10;	//error Due to private
		//setCounter(10);// not Exists
		//System.out.println(Student.counter);//error Due to private
		System.out.println(getCounter());
		
		
		Student object1=new Student();
		object1.setName("Akash");
		
		Student object2=new Student();
		object2.setName("Aman");
		
		System.out.println(getCounter());
		
	}

}
