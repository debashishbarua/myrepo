package com.cts.main;

import com.cts.entity.Employee;

public class MainApplication {
	
	public static void main(String[] args) {
		
		//Employee employeeOne=new Employee();
		//Employee employeeTwo=new Employee(10, "Akash");
		//Employee employeeThree=new Employee(11);
		//Employee employeeFour=new Employee("Aman");
		
		//To Store the group of values array
		
		Employee employees[];//Declaration of array
		employees = new Employee[5];// Object creation of array for employees
		//Initialize thre value on the array
		employees[0] =new Employee();// 1st employee
		employees[1] =new Employee(10, "Akash");
		employees[2] =new Employee(11);
		employees[3] =new Employee("Aman");
		employees[4] =new Employee(111);
		//Alt
		Employee employeesAlt[] = {
				new Employee(),	
				new Employee(10, "Akash"),
				new Employee(11),
				new Employee("Aman")
		};
		// Direct access of array
		System.out.println(employees[1].getId() + " " + employees[1].getName());
		//Set the id & name of first employee is 100 Mr. X
		employees[0].setId(100);
		employees[0].setName("Mr. x");
		
		//If the employee name is null then assign the name Mr. K
		for(int idx=0 ;idx<employees.length;idx++) {
			if(employees[idx].getName() == null) {
				employees[idx].setName("Mr. K");
			}
		}
		//Traversing the arra
		System.out.println("Displat Employees:");
		for(int idx=0 ;idx<employees.length;idx++) {
			System.out.println(employees[idx].getId() + " " + employees[idx].getName());
		}
		/*
		// Store 5 integer in a array		
		int integers[]; 
		int []integersAlt;		
		//Create the object of array
		integers =new int[5];
		integersAlt=new int[5];		
		int arr[] = new int[5];
		
		integers[0] =10;
		integers[1] =11;
		integers[2] =100;
		integers[3] =101;
		integers[4] =101;
			int k=10;
		int arr[] = {2,3,4,5};
		*/
		

	}
}
